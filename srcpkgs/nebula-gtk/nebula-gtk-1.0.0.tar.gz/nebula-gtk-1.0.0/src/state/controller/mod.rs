pub(crate) mod app;
pub(crate) mod discover;
pub(crate) mod installed;
pub(crate) mod tools;
pub(crate) mod updates;

pub(crate) use app::AppController;
