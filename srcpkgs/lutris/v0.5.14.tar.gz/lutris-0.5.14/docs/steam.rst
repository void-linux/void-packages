
AppState
--------
::

    StateInvalid         0
    StateUninstalled     1
    StateUpdateRequired  2
    StateFullyInstalled  4
    StateEncrypted       8
    StateLocked          16
    StateFilesMissing    32
    StateAppRunning      64
    StateFilesCorrupt    128
    StateUpdateRunning   256
    StateUpdatePaused    512
    StateUpdateStarted   1024
    StateUninstalling    2048
    StateBackupRunning   4096
    StateReconfiguring   65536
    StateValidating      131072
    StateAddingFiles     262144
    StatePreallocating   524288
    StateDownloading     1048576
    StateStaging         2097152
    StateCommitting      4194304
    StateUpdateStopping  8388608
