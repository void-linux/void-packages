class UnsupportedProvider(Exception):
    """Error that represents an unsupported provider"""
